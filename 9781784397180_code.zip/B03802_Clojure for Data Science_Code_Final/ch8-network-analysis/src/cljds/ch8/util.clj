(ns cljds.ch8.util)

(defn to-long [s]
  (Long/parseLong s))
